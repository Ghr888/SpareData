﻿using Sirenix.OdinInspector;
namespace JKFrame
{
    /// <summary>
    /// 配置基类
    /// 角色配置、武器配置等等
    /// </summary>
    public class ConfigBase : SerializedScriptableObject
    {

    }
}